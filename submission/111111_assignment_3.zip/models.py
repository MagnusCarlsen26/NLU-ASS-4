import torch
import torch.nn as nn
import torch.nn.functional as F

class FFNN(nn.Module):
    """
    Feed-Forward Neural Network for sentiment analysis
    
    Architecture:
    - Input layer (one-hot encoded tokens)
    - First hidden layer (size 256)
    - Second hidden layer (size 128)
    - Output layer (size depends on number of classes)
    """
    def __init__(self, input_size, hidden_size1=256, hidden_size2=128, num_classes=2):
        super(FFNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.fc3 = nn.Linear(hidden_size2, num_classes)
        self.dropout = nn.Dropout(0.5)
        
    def forward(self, x):
        # Flatten the input to handle one-hot encoding
        batch_size, seq_len, input_size = x.size()
        x = x.view(batch_size, -1)  # Flatten to [batch_size, seq_len * input_size]
        
        # First hidden layer with ReLU activation
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        
        # Second hidden layer with ReLU activation
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        
        # Output layer
        x = self.fc3(x)
        
        return x

class LSTM(nn.Module):
    """
    LSTM model for sentiment analysis
    
    Architecture:
    - Input layer (one-hot encoded tokens)
    - LSTM layer (hidden size 256)
    - Output layer (size depends on number of classes)
    """
    def __init__(self, input_size, hidden_size=256, num_classes=2):
        super(LSTM, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, num_classes)
        self.dropout = nn.Dropout(0.5)
        
    def forward(self, x):
        # LSTM expects input of shape [batch_size, seq_len, input_size]
        # which is what our input is already formatted as
        
        # Run through LSTM
        lstm_out, (hidden, cell) = self.lstm(x)
        
        # Use the last hidden state for classification
        out = self.dropout(hidden[-1])
        out = self.fc(out)
        
        return out 